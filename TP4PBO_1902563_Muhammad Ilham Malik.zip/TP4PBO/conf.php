<?php

//file untuk menyambungkan ke basis data

$db_host = "127.0.0.1"; //untuk mengakses localhost url
$db_user = "root"; //usernamenya menggunakan root
$db_password = ""; //tidak memasukan password
$db_name = "tp4pbo"; //nama database yang ingin diakses

?>